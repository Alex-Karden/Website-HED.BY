<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache

define('WP_SITEURL', 'http://'. $_SERVER['HTTP_HOST']);
define('WP_HOME', 'http://'. $_SERVER['HTTP_HOST']);


/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи, язык WordPress и ABSPATH. Дополнительную информацию можно найти
 * на странице {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется сценарием создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'oof_hedby');

/** Имя пользователя MySQL */
define('DB_USER', 'oof_hedby');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'oof_hedby');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется снова авторизоваться.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'T1PEK~)4F{(9.*?pij@`,K_WtGbXDCT:vL<jpLa|bxMuGUOsjj3dG3:MYcb:o2q`');
define('SECURE_AUTH_KEY',  '?%rV&&7+.:H5H8`r+pP-sl=v?%p,x13T(%u_IoAK%n(590g,O^mZ6^-d;9elvjon');
define('LOGGED_IN_KEY',    'b,<BoBxMlFg{/2oV8zY?3z/+Up#o`<A:gki1|xUDP><dZ5(WwV;U4}wW*l[_4!S:');
define('NONCE_KEY',        'l4^#3P b=q*X<pRS0|&MnS(K(H1}7wxA,;v;:j;}yO1f>l?)[?I2uv}(n.K7{W$M');
define('AUTH_SALT',        'I/1&j@sZQoAHnSctam{.?Fkl}}ZY! a6T<76PaITFEsz|_p!Xo@J+9zR:Gi**bku');
define('SECURE_AUTH_SALT', '??b7F)5v)r:@:V@k>2qu1S3s$G<Y1<;o0Ft3 3rBJkyP1Eni=DgOB=x]a*Cw8}jb');
define('LOGGED_IN_SALT',   ';(~X2#:o!/QW>R9%4Xo;6EAUTd%Ssb`}MZO8dqgl#K#`LdH+{Wv(HRXhg#R#-Ivm');
define('NONCE_SALT',       '/leP}1nDr%/,M8X?f(o2PX;`auL^@=A&J&&8{o_8Jk(+ hsyR9d%.<8.)p6726}t');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько блогов в одну базу данных, если вы будете использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Язык локализации WordPress, по умолчанию английский.
 *
 * Измените этот параметр, чтобы настроить локализацию. Соответствующий MO-файл
 * для выбранного языка должен быть установлен в wp-content/languages. Например,
 * чтобы включить поддержку русского языка, скопируйте ru_RU.mo в wp-content/languages
 * и присвойте WPLANG значение 'ru_RU'.
 */
define('WPLANG', 'ru_RU');

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Настоятельно рекомендуется, чтобы разработчики плагинов и тем использовали WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
